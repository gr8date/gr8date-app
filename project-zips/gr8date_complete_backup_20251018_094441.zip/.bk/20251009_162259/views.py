from __future__ import annotations
from django.db.models import Q, Subquery
from django.contrib import messages as dj_messages
from django.views.decorators.http import require_POST
# pages/views

from datetime import date
from typing import Optional

from django.contrib import messages
from django.contrib.auth import logout, get_user_model, authenticate, login
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Prefetch, Q
from django.http import HttpResponse, JsonResponse, HttpResponseBadRequest, Http404
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.views.generic import ListView, DetailView

from .models import Blog, Profile, ProfileImage, Thread, Message

User = get_user_model()

# ============================================================================
# Blog
# ============================================================================
class BlogListView(ListView):
    template_name = "pages/blog_list.html"
    model = Blog
    context_object_name = "posts"
    paginate_by = 12
    def get_queryset(self):
        now = timezone.now()
        return (
            Blog.objects.filter(status=Blog.Status.PUBLISHED, published_at__lte=now)
            .select_related("author")
            .order_by("-published_at")
        )


class BlogDetailView(DetailView):
    template_name = "pages/blog_detail.html"
    model = Blog
    context_object_name = "post"
    slug_field = "slug"
    slug_url_kwarg = "slug"
    def get_queryset(self):
        now = timezone.now()
        return (
            Blog.objects.filter(status=Blog.Status.PUBLISHED, published_at__lte=now)
            .select_related("author")
            .order_by("-published_at")
        )
def _ensure_profile(user) -> Profile:
    try:
        return user.profile
    except Profile.DoesNotExist:
        return Profile.objects.create(user=user)


def _allow_full_access(profile: Profile) -> bool:
    """Full dashboard access only if profile is_complete AND is_approved."""
    is_complete = getattr(profile, "is_complete", False)
    approved = getattr(profile, "is_approved", False)
    return bool(is_complete and approved)


def _age_from_dob(dob: Optional[date]) -> Optional[int]:
    if not dob:
        return None
    today = date.today()
    years = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
    return max(0, years)


    """Return first public primary image URL, else any public image, else None."""
    images = getattr(profile, "images_cached", None)
    if images is None:
        images = ProfileImage.objects.filter(profile=profile, is_private=False).order_by(
            "-is_primary", "-created_at"
        )
    primary = next((im for im in images if getattr(im, "is_primary", False)), None)
    if primary and primary.image:
        return primary.image.url
    any_img = next((im for im in images if im.image), None)
    return any_img.image.url if any_img else None


# ============================================================================
# Auth handlers
# ============================================================================
def auth_login_view(request):
    """Handles POSTs from login page."""
    if request.method != "POST":
        return render(request, "pages/login_gr8date_user_or_email_showpw.html")

    ident = (request.POST.get("identifier") or request.POST.get("username") or "").strip()
    password = (request.POST.get("password") or "").strip()

    username = ident
    if "@" in ident:
        try:
            user_obj = User.objects.get(email__iexact=ident)
            username = user_obj.username
        except User.DoesNotExist:
            pass

    user = authenticate(request, username=username, password=password)
    if user is None:
        messages.error(request, "Invalid credentials. Please try again.")
        return redirect("login")

    login(request, user)
    prof = _ensure_profile(user)
    return redirect("dashboard" if _allow_full_access(prof) else "preview")


def auth_signup_view(request):
    """Handles POSTs from join page."""
    if request.method != "POST":
        return render(request, "pages/join_gr8date_singlepw_show.html")

    email = (request.POST.get("email") or "").strip()
    password = (request.POST.get("password") or "").strip()

    if not email or not password:
        messages.error(request, "Please provide both email and password.")
        return redirect("join")

    if User.objects.filter(email__iexact=email).exists():
        messages.error(request, "An account with that email already exists.")
        return redirect("login")

    base = email.split("@", 1)[0] or "user"
    candidate = base
    i = 1
    while User.objects.filter(username__iexact=candidate).exists():
        i += 1
        candidate = f"{base}{i}"

    user = User.objects.create_user(username=candidate, email=email, password=password)
    _ensure_profile(user)
    login(request, user)
    return redirect("preview")


def logout_view(request):
    logout(request)
    return redirect("home")


# ============================================================================
# Preview gate / Dashboard / Profile
# ============================================================================
def preview_gate(request):
    """Landing for users waiting for approval."""
    return render(request, "pages/gr8date_preview_gate.html")


@login_required
def dashboard(request):
    from django.core.paginator import Paginator
    from django.shortcuts import render
    from django.utils import timezone
    from .models import Profile

    qs = (Profile.objects
          .select_related("user")
          .prefetch_related("images")
          .order_by("-created_at"))
    paginator = Paginator(qs, 12)
    page_obj = paginator.get_page(request.GET.get("page"))
    preview_mode = request.GET.get("preview") == "1"

    for p in page_obj.object_list:
        # --- image url (robust) ---
        url = None
        # try property if present
        try:
            url = getattr(p, "primary_image_url", None)
        except Exception:
            url = None
        # fallbacks
        if not url:
            img = None
            # property or method
            try:
                img = getattr(p, "primary_image", None)
                if callable(img):
                    img = img()
            except Exception:
                img = None
            if not img and hasattr(p, "images"):
                try:
                    img = p.images.filter(is_primary=True).first()
                except Exception:
                    img = None
            if img:
                try:
                    url = img.image.url
                except Exception:
                    url = None
        setattr(p, "primary_image_url_fallback", url or "")

        # --- age (fallback) ---
        age_val = getattr(p, "age", None)
        if age_val is None and getattr(p, "date_of_birth", None):
            dob = p.date_of_birth
            today = timezone.localdate()
            age_val = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
        setattr(p, "age_fallback", age_val)

    return render(
        request,
        "pages/gr8date_dashboard_fixed_v10_nolines.html",
        {"profiles": page_obj, "preview_mode": preview_mode},
    )

def profile_create(request):
    """Create or update minimal profile."""
    prof = _ensure_profile(request.user)

    if request.method == "POST":
        prof.headline = (request.POST.get("headline") or "").strip()
        prof.location = (request.POST.get("location") or "").strip()
        prof.about = (request.POST.get("about") or "").strip()

        dob_str = (request.POST.get("date_of_birth") or "").strip()
        if dob_str:
            try:
                y, m, d = [int(x) for x in dob_str.split("-")]
                prof.date_of_birth = date(y, m, d)
            except Exception:
                prof.date_of_birth = None

        prof.my_gender = (request.POST.get("my_gender") or "").strip()
        prof.looking_for = (request.POST.get("looking_for") or "").strip()

        if hasattr(prof, "is_complete"):
            prof.is_complete = True
        if hasattr(prof, "is_approved") and prof.is_approved is None:
            prof.is_approved = False

        prof.save()
        messages.success(request, "Profile saved; pending admin approval.")
        return redirect("dashboard")

    return render(request, "pages/my_profile_create_full_v22_interests_in_lifestyle.html", {"blocked_by_me": blocked_by_me, "blocked_either": blocked_either, "me": prof})


@login_required
def profile_preview(request):
    me = _ensure_profile(request.user)
    lock = not _allow_full_access(me)
    context = {
        "me": me,
        "age": _age_from_dob(getattr(me, "date_of_birth", None)),
        "public_images": ProfileImage.objects.filter(profile=me, is_private=False).order_by("-is_primary", "-created_at")[:4],
        "private_images": ProfileImage.objects.filter(profile=me, is_private=True).order_by("-created_at")[:4],
        "preview_mode": lock,
        "lock_media": lock,
    }
    return render(request, "pages/gr8date_profile_flexible_lightbox_fix_navbars_centered_red_smaller.html", context)


# ============================================================================
# Public Profile
# ============================================================================
def profile_public(request, pk: int):
    blocked_by_me = False
    blocked_either = False
    if request.user.is_authenticated:
        try:
            prof_user = prof.user  # expecting 'prof' context var from your existing code
            blocked_by_me = Block.objects.filter(blocker=request.user, blocked=prof_user).exists()
            blocked_either = is_blocked(request.user, prof_user)
        except Exception:
            pass
    prof = get_object_or_404(Profile.objects.select_related("user"), pk=pk)
    public_images = ProfileImage.objects.filter(profile=prof, is_private=False).order_by("-is_primary", "-created_at")[:8]
    private_images = ProfileImage.objects.filter(profile=prof, is_private=True).order_by("-created_at")[:8]

    viewer_preview = True
    if request.user.is_authenticated:
        try:
            vp = request.user.profile
            viewer_preview = not (_allow_full_access(vp))
        except Profile.DoesNotExist:
            viewer_preview = True

    ctx = {
        "me": prof,
        "age": _age_from_dob(getattr(prof, "date_of_birth", None)),
        "public_images": public_images,
        "private_images": private_images,
        "preview_mode": viewer_preview,
        "lock_media": viewer_preview,
    }
    return render(request, "pages/my_profile_create_full_v22_interests_in_lifestyle.html", {"blocked_by_me": blocked_by_me, "blocked_either": blocked_either, "me": prof})


# ============================================================================
# Search
# ============================================================================
@login_required
def search_view(request):
    """Simple profile search with staff-only gender filter."""
    from datetime import date

    def age_to_dob_bounds(age_min, age_max):
        today = date.today()
        dob_min = dob_max = None
        if age_min:
            dob_max = date(today.year - age_min, today.month, today.day)
        if age_max:
            dob_min = date(today.year - age_max, today.month, today.day)
        return dob_min, dob_max

    q = (request.GET.get("q") or "").strip()
    age_min = int(request.GET.get("age_min") or 0) or None
    age_max = int(request.GET.get("age_max") or 0) or None
    gender = (request.GET.get("gender") or "").strip()

    qs = Profile.objects.select_related("user").prefetch_related(
        Prefetch("images", queryset=ProfileImage.objects.filter(is_private=False), to_attr="images_cached")
    ).filter(is_complete=True, is_approved=True)

    if q:
        qs = qs.filter(
            Q(user__username__icontains=q)
            | Q(headline__icontains=q)
            | Q(about__icontains=q)
            | Q(location__icontains=q)
        )

    dob_min, dob_max = age_to_dob_bounds(age_min, age_max)
    if dob_min:
        qs = qs.filter(date_of_birth__gte=dob_min)
    if dob_max:
        qs = qs.filter(date_of_birth__lte=dob_max)
    if request.user.is_staff and gender:
        qs = qs.filter(my_gender__iexact=gender)

    paginator = Paginator(qs, 12)
    page_obj = paginator.get_page(request.GET.get("page", 1))
    for p in page_obj.object_list:
        p.card_age = _age_from_dob(getattr(p, "date_of_birth", None))

    return render(request, "pages/search.html", {"page_obj": page_obj, "total": paginator.count})


# ============================================================================
# Messages (Inbox, Send, Thread Detail, Unread Count)
# ============================================================================
@login_required
def messages_inbox(request):
    me = request.user
    prefill_user = None
    to_param = request.GET.get("to")
    if to_param:
        try:
            candidate = User.objects.get(pk=int(to_param))
            if candidate != me and not is_blocked(me, candidate):
                prefill_user = candidate
        except (User.DoesNotExist, ValueError):
            pass
    me = request.user
    threads = Thread.for_user(me).order_by("-created_at")
    items = []
    for t in threads:
        other = t.user_a if t.user_b_id == me.id else t.user_b
        last_msg = Message.objects.filter(thread=t).order_by("-created_at").first()
        unread_count = Message.objects.filter(thread=t, recipient=me, is_read=False).count()
        items.append({
            "id": t.id,
            "other_id": other.id,
            "other_username": getattr(other, "username", str(other.pk)),
            "last_text": (last_msg.text if last_msg else ""),
            "last_when": (last_msg.created_at if last_msg else None),
            "unread": unread_count,
        })
    return render(request, "pages/admin_messages_inbox_wireframe.html", {"inbox_prefill_user": prefill_user, "threads": items})


@login_required
def messages_thread_detail(request, thread_id: int):
    me = request.user
    thread = get_object_or_404(Thread, id=thread_id)
    if not (thread.user_a_id == me.id or thread.user_b_id == me.id):
        raise Http404("Conversation not found")

    other = thread.user_a if thread.user_b_id == me.id else thread.user_b
    Message.objects.filter(thread=thread, recipient=me, is_read=False).update(is_read=True)
    q = Message.objects.filter(thread=thread).order_by("-created_at")
    paginator = Paginator(q, 50)
    page_obj = paginator.get_page(request.GET.get("page", 1))
    msgs_chrono = list(reversed(list(page_obj.object_list)))

    return render(request, "pages/messages_thread.html", {"thread": thread, "other": other, "messages": msgs_chrono})


@login_required
def messages_send(request):
    if request.method != "POST":
        return HttpResponseBadRequest("POST only")

    me = request.user
    to_id = request.POST.get("to_id")
    text = (request.POST.get("text") or "").strip()

    if not to_id or not text:
        return JsonResponse({"ok": False, "error": "Missing to_id or text"}, status=400)
    if len(text) > 2000:
        return JsonResponse({"ok": False, "error": "Too long (>2000 chars)."}, status=400)

    try:
        other = User.objects.get(pk=int(to_id))
    except (User.DoesNotExist, ValueError):
        return JsonResponse({"ok": False, "error": "Recipient not found"}, status=404)

    if other.id == me.id:
        return JsonResponse({"ok": False, "error": "Cannot message yourself"}, status=400)

    # Block check
    if is_blocked(me, other):
        return JsonResponse({"ok": False, "error": "Messaging is disabled (user blocked)."}, status=403)

    thread = Thread.get_or_create_for(me, other)
    Message.objects.create(thread=thread, sender=me, recipient=other, text=text, is_read=False)
    return JsonResponse({"ok": True, "message": "Sent", "thread_id": thread.id})

    if request.method != "POST":
        return HttpResponseBadRequest("POST only")

    me = request.user
    to_id = request.POST.get("to_id")
    text = (request.POST.get("text") or "").strip()
    if not to_id or not text:
        return JsonResponse({"ok": False, "error": "Missing to_id or text"}, status=400)

    try:
        other = User.objects.get(pk=int(to_id))
    except (User.DoesNotExist, ValueError):
        return JsonResponse({"ok": False, "error": "Recipient not found"}, status=404)
    if other.id == me.id:
        return JsonResponse({"ok": False, "error": "Cannot message yourself"}, status=400)

    thread = Thread.get_or_create_for(me, other)
    Message.objects.create(thread=thread, sender=me, recipient=other, text=text, is_read=False)
    return JsonResponse({"ok": True, "message": "Sent", "thread_id": thread.id})


@login_required
def messages_unread_count(request):
    """Enhanced endpoint returning unread count + preview flag."""
    me = request.user
    profile = _ensure_profile(me)
    if not profile:
        return JsonResponse({"count": 0, "preview": False})

    is_preview = profile.is_complete and not profile.is_approved
    qs = Message.objects.filter(recipient=me, is_read=False)
    if is_preview:
        qs = qs.filter(sender__is_staff=True)
    return JsonResponse({"count": qs.count(), "preview": is_preview})


# ============================================================================
# Icons / Misc
# ============================================================================
@login_required
def matches_view(request):
    return render(request, "pages/matches.html")


@login_required
def hotdates_list(request):
    return render(request, "pages/hotdate_server_list.html")


@login_required
def hotdates_create(request):
    return render(request, "pages/hotdate_server_create.html")


@login_required
def account_settings(request):
    return render(request, "pages/account_settings.html")


from .models import Block, is_blocked


@login_required
@require_POST
def block_user(request, user_id: int):
    me = request.user
    if me.id == user_id:
        return HttpResponseBadRequest("Cannot block yourself.")
    other = get_object_or_404(User, pk=user_id)
    Block.objects.get_or_create(blocker=me, blocked=other)
    dj_messages.success(request, f"You have blocked {other.username}.")
    return redirect("profile_public", pk=other.id)


@login_required
@require_POST
def unblock_user(request, user_id: int):
    me = request.user
    other = get_object_or_404(User, pk=user_id)
    Block.objects.filter(blocker=me, blocked=other).delete()
    dj_messages.success(request, f"You have unblocked {other.username}.")
    return redirect("profile_public", pk=other.id)
